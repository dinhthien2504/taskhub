const t="http://3.25.122.55/api";export{t as B};
