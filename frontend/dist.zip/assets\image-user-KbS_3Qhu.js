const s="/images/image-user.svg";export{s as _};
